#ifndef FUNC_H
#define FUNC_H

double f(double x);
double df(double x);

#endif